# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['lyra_orm', 'lyra_orm.config', 'lyra_orm.models']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.3.16,<2.0.0', 'psycopg2>=2.8.5,<3.0.0']

setup_kwargs = {
    'name': 'lyra-orm',
    'version': '0.2.2',
    'description': 'A ORM for lyra database, with models, schema and more.',
    'long_description': None,
    'author': 'Eric Souza',
    'author_email': 'ericsouza0801@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
